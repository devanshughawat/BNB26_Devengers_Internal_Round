import React, { useState } from 'react';
import { Artifact, ArtifactType } from '../types/forensic';
import { 
  X, 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Globe, 
  Video, 
  Sparkles, 
  Clock, 
  Camera, 
  Check 
} from 'lucide-react';

interface AddArtifactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (artifact: Artifact) => void;
}

export const AddArtifactModal: React.FC<AddArtifactModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [type, setType] = useState<ArtifactType>('post');
  const [title, setTitle] = useState('');
  const [source, setSource] = useState('');
  const [author, setAuthor] = useState('');
  const [timestamp, setTimestamp] = useState(new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC');
  const [content, setContent] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [exifDate, setExifDate] = useState('');
  const [cameraDevice, setCameraDevice] = useState('');
  const [softwareOrigin, setSoftwareOrigin] = useState('');
  const [isScanning, setIsScanning] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        setMediaUrl(base64);
        if (!title) setTitle(file.name.replace(/\.[^/.]+$/, ''));
        
        // Auto-run OCR / Visual Scan via backend
        setIsScanning(true);
        try {
          const res = await fetch('/api/ocr-extract', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: base64, mimeType: file.type }),
          });
          const data = await res.json();
          if (data.extractedText && !content) {
            setContent(data.extractedText);
          }
        } catch (err) {
          console.error(err);
        } finally {
          setIsScanning(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() && !content.trim()) return;

    const newArtifact: Artifact = {
      id: `art-custom-${Date.now().toString().slice(-4)}`,
      type,
      title: title.trim() || 'Custom Artifact',
      source: source.trim() || 'Direct User Upload',
      timestamp: timestamp.trim() || new Date().toISOString(),
      author: author.trim() || 'Unknown',
      content: content.trim(),
      mediaUrl: mediaUrl || undefined,
      metadata: {
        exifDate: exifDate.trim() || undefined,
        cameraDevice: cameraDevice.trim() || undefined,
        softwareOrigin: softwareOrigin.trim() || undefined,
        fileHash: `sha256:${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`,
      },
      individualAnalysis: {
        visualArtifactScore: mediaUrl ? Math.floor(Math.random() * 30 + 10) : 5,
        syntheticClues: [],
        ocrExtractedText: content.trim(),
        manipulationMarkers: [],
        metadataIntegrity: exifDate ? 'clean' : 'stripped',
      },
    };

    onAdd(newArtifact);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 text-slate-200 shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <span className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Upload className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-base font-bold text-white">Add Digital Artifact</h3>
              <p className="text-xs text-slate-400">
                Upload image, screenshot, news dispatch, or social post for cross-analysis.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Artifact Type Pills */}
          <div>
            <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1.5">
              Artifact Format
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
              {(['post', 'image', 'screenshot', 'article', 'video'] as ArtifactType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`py-1.5 px-2 rounded-lg font-mono capitalize text-[11px] border transition ${
                    type === t
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Title & Source */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">
                Artifact Label / Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Viral Photo on X / Telegram Alert"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">
                Source Channel / Domain
              </label>
              <input
                type="text"
                value={source}
                onChange={(e) => setSource(e.target.value)}
                placeholder="e.g. @NewsChannel on Telegram / X"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-xs"
              />
            </div>
          </div>

          {/* Author & Timestamp */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">
                Author / Uploader Handle
              </label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="e.g. @breaking_feed"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">
                Published Timestamp
              </label>
              <input
                type="text"
                value={timestamp}
                onChange={(e) => setTimestamp(e.target.value)}
                placeholder="2026-10-03 14:00:00 UTC"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-xs"
              />
            </div>
          </div>

          {/* Media File Upload or URL */}
          <div>
            <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">
              Visual Asset (Image / Screenshot)
            </label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <label className="cursor-pointer flex items-center space-x-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
                  <Upload className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Choose Image File...</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                {isScanning && (
                  <span className="text-[11px] text-indigo-400 font-mono flex items-center space-x-1">
                    <Sparkles className="w-3 h-3 animate-spin" />
                    <span>Extracting OCR...</span>
                  </span>
                )}
              </div>

              {mediaUrl && (
                <div className="relative h-24 w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                  <img src={mediaUrl} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setMediaUrl('')}
                    className="absolute top-1 right-1 p-1 rounded-full bg-slate-900/80 text-rose-400 hover:bg-slate-900"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Content / OCR Text */}
          <div>
            <label className="block text-slate-400 font-mono text-[10px] uppercase mb-1">
              Text Content / Post Body / Extracted Claims *
            </label>
            <textarea
              required
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Paste caption, statement, tweet text, or claims to cross-analyze..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-xs leading-relaxed"
            />
          </div>

          {/* Optional EXIF & Forensic Parameters */}
          <div className="pt-2 border-t border-slate-800 space-y-2">
            <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">
              Optional Forensic &amp; EXIF Metadata
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                value={exifDate}
                onChange={(e) => setExifDate(e.target.value)}
                placeholder="EXIF Date (e.g. 2018-08-16)"
                className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none"
              />
              <input
                type="text"
                value={cameraDevice}
                onChange={(e) => setCameraDevice(e.target.value)}
                placeholder="Camera Model (e.g. Sony A7R)"
                className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none"
              />
              <input
                type="text"
                value={softwareOrigin}
                onChange={(e) => setSoftwareOrigin(e.target.value)}
                placeholder="Software (e.g. Midjourney / PS)"
                className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs font-mono focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition flex items-center space-x-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Add to Investigation</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
