import React, { useState } from 'react';
import { Artifact, ClassificationResult } from './types/forensic';
import { INVESTIGATION_CASES } from './data/mockInvestigations';
import { Sidebar } from './components/Sidebar';
import { DashboardOverview, FeedDetection } from './components/DashboardOverview';
import { InvestigationView } from './components/InvestigationView';
import { EvidenceGraph } from './components/EvidenceGraph';
import { BenchmarkSuite } from './components/BenchmarkSuite';
import { AddArtifactModal } from './components/AddArtifactModal';
import { ExportModal } from './components/ExportModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [activeCaseTitle, setActiveCaseTitle] = useState<string>(INVESTIGATION_CASES[0].title);
  const [artifacts, setArtifacts] = useState<Artifact[]>(INVESTIGATION_CASES[0].artifacts);
  const [result, setResult] = useState<ClassificationResult | null>(INVESTIGATION_CASES[0].precomputedAnalysis || null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Run Cross-Artifact Analysis
  const handleRunAnalysis = async () => {
    if (artifacts.length === 0) return;
    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ artifacts }),
      });
      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error('Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // When user clicks a detection item in the Live Detection Feed
  const handleSelectDetection = (item: FeedDetection) => {
    const matchedCase = INVESTIGATION_CASES.find((c) => c.id === item.caseId) || INVESTIGATION_CASES[0];
    setActiveCaseTitle(item.title);
    setArtifacts(matchedCase.artifacts);
    setResult(matchedCase.precomputedAnalysis || null);
    setCurrentTab('investigations');
  };

  // Add custom artifact
  const handleAddArtifact = (newArt: Artifact) => {
    setArtifacts((prev) => [newArt, ...prev]);
    setResult(null);
  };

  // Remove artifact
  const handleRemoveArtifact = (id: string) => {
    setArtifacts((prev) => prev.filter((a) => a.id !== id));
    setResult(null);
  };

  // Open New Analysis Flow
  const handleOpenNewAnalysis = () => {
    setActiveCaseTitle('New Cross-Artifact Investigation');
    setArtifacts([]);
    setResult(null);
    setIsAddModalOpen(true);
    setCurrentTab('investigations');
  };

  return (
    <div className="flex h-screen bg-[#0A0D14] text-slate-100 font-sans antialiased overflow-hidden selection:bg-sky-500 selection:text-white">
      {/* Left Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={(tab) => {
          if (tab === 'submit') {
            setIsAddModalOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 md:p-8">
        <div className="max-w-7xl mx-auto">
          {/* TAB 1: OVERVIEW (Matches exact Pixso mockup screenshot) */}
          {currentTab === 'overview' && (
            <DashboardOverview
              onOpenNewAnalysis={handleOpenNewAnalysis}
              onSelectDetection={handleSelectDetection}
              onOpenNetworks={() => setCurrentTab('networks')}
            />
          )}

          {/* TAB 2: INVESTIGATIONS WORKSPACE */}
          {currentTab === 'investigations' && (
            <InvestigationView
              caseTitle={activeCaseTitle}
              artifacts={artifacts}
              result={result}
              onBack={() => setCurrentTab('overview')}
              onRunAnalysis={handleRunAnalysis}
              isAnalyzing={isAnalyzing}
              onAddArtifact={handleAddArtifact}
              onRemoveArtifact={handleRemoveArtifact}
              onExport={() => setIsExportModalOpen(true)}
            />
          )}

          {/* TAB 3: ACCOUNT NETWORKS (Interactive Graph) */}
          {currentTab === 'networks' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    Account &amp; Disinformation Networks
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Interactive topological graph of accounts, coordinated echoing clusters, and shared media hashes
                  </p>
                </div>
                <button
                  onClick={() => setCurrentTab('overview')}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[#0F1422] hover:bg-[#141B2D] text-slate-300 border border-[#1A2336] transition"
                >
                  Back to Overview
                </button>
              </div>

              {result ? (
                <EvidenceGraph
                  nodes={result.graph.nodes}
                  edges={result.graph.edges}
                  height="640px"
                />
              ) : (
                <div className="p-12 text-center rounded-2xl bg-[#0F1422] border border-[#1A2336] text-slate-400 text-xs">
                  Run an investigation first to populate the account network graph.
                </div>
              )}
            </div>
          )}

          {/* TAB 4: UNSEEN MANIPULATION BENCHMARK */}
          {currentTab === 'benchmark' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    Unseen Manipulation Benchmark Suite
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Evaluate engine performance against 6 zero-day and unseen manipulation patterns
                  </p>
                </div>
                <button
                  onClick={() => setCurrentTab('overview')}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-[#0F1422] hover:bg-[#141B2D] text-slate-300 border border-[#1A2336] transition"
                >
                  Back to Overview
                </button>
              </div>

              <BenchmarkSuite
                onLoadBenchmarkCase={(benchArtifacts, title) => {
                  setArtifacts(benchArtifacts);
                  setActiveCaseTitle(title);
                  setResult(null);
                  setCurrentTab('investigations');
                }}
              />
            </div>
          )}

          {/* TAB 5: CONTENT LIBRARY */}
          {currentTab === 'library' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">
                    Content Library
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Catalog of indexed media, flagged posts, reverse hash matches, and forensic telemetry
                  </p>
                </div>
                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-sky-600 hover:bg-sky-500 text-white shadow-md transition"
                >
                  + Add Content
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {INVESTIGATION_CASES.flatMap((c) => c.artifacts).map((art) => (
                  <div
                    key={art.id}
                    className="p-4 rounded-xl bg-[#0F1422] border border-[#1A2336] space-y-3"
                  >
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-sky-400 uppercase">#{art.id}</span>
                      <span className="text-slate-500 capitalize">{art.type}</span>
                    </div>
                    {art.mediaUrl && (
                      <div className="h-32 rounded-lg overflow-hidden bg-slate-950 border border-[#1A2336]">
                        <img src={art.mediaUrl} alt={art.title} className="w-full h-full object-cover" />
                      </div>
                    )}
                    <h4 className="text-xs font-semibold text-white">{art.title}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2">
                      {art.content}
                    </p>
                    <div className="text-[10px] text-slate-500 font-mono pt-2 border-t border-[#161D2B]">
                      Source: {art.source}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: ALERTS */}
          {currentTab === 'alerts' && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold text-white tracking-tight">
                High-Priority Intelligence Alerts
              </h2>
              <div className="space-y-2">
                <div className="p-4 rounded-xl bg-[#0F1422] border border-rose-900/40 flex items-start space-x-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 mt-1.5" />
                  <div>
                    <h4 className="text-xs font-bold text-rose-300">
                      Coordinated Inauthentic Campaign #7823 Exceeding Threshold
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5">
                      47 bot accounts synchronized within 4 minutes spreading identical Flux.1 synthetic fire image.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0F1422] border border-amber-900/40 flex items-start space-x-3">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 mt-1.5" />
                  <div>
                    <h4 className="text-xs font-bold text-amber-300">
                      Viral Decontextualization Alert: Northern Valley Dam
                    </h4>
                    <p className="text-xs text-slate-300 mt-0.5">
                      Recycled 2018 Indian monsoon flood photo matched via reverse hashing with 89.1% perceptual similarity.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: REPORTS / SETTINGS FALLBACK */}
          {(currentTab === 'reports' || currentTab === 'settings') && (
            <div className="p-12 text-center rounded-2xl bg-[#0F1422] border border-[#1A2336] space-y-3">
              <h3 className="text-base font-bold text-white capitalize">{currentTab}</h3>
              <p className="text-xs text-slate-400">
                TruthLens AI v2.4 Authenticity Intelligence is operating normally.
              </p>
              <button
                onClick={() => setCurrentTab('overview')}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white transition"
              >
                Return to Overview
              </button>
            </div>
          )}
        </div>
      </main>

      {/* Add Artifact Modal */}
      <AddArtifactModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddArtifact}
      />

      {/* Export Report Modal */}
      {result && (
        <ExportModal
          isOpen={isExportModalOpen}
          onClose={() => setIsExportModalOpen(false)}
          result={result}
          artifacts={artifacts}
          caseTitle={activeCaseTitle}
        />
      )}
    </div>
  );
}
