export type ArtifactType = 'image' | 'video' | 'post' | 'screenshot' | 'article' | 'url';

export interface ArtifactMetadata {
  exifDate?: string;
  cameraDevice?: string;
  fileHash?: string;
  compressionQuality?: number;
  geoCoordinates?: string;
  softwareOrigin?: string;
  sourceDomain?: string;
}

export interface IndividualAnalysis {
  visualArtifactScore: number; // 0 - 100
  syntheticClues: string[];
  ocrExtractedText?: string;
  manipulationMarkers: string[];
  metadataIntegrity: 'clean' | 'suspicious' | 'stripped' | 'modified';
}

export interface Artifact {
  id: string;
  type: ArtifactType;
  title: string;
  source: string;
  timestamp: string;
  author: string;
  content: string;
  mediaUrl?: string;
  url?: string;
  metadata?: ArtifactMetadata;
  individualAnalysis?: IndividualAnalysis;
}

export interface EvidenceItem {
  id: string;
  type: 'positive' | 'negative' | 'neutral';
  category: 'visual_match' | 'temporal_mismatch' | 'cross_post_repetition' | 'metadata_conflict' | 'narrative_contradiction' | 'ai_synthesis';
  label: string;
  description: string;
  artifactsInvolved: string[];
  confidenceContribution: number;
}

export interface UncertaintyItem {
  id: string;
  type: 'conflict' | 'missing_signal' | 'ambiguity';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  mitigation: string;
}

export interface GraphNode {
  id: string;
  label: string;
  type: 'artifact' | 'claim' | 'entity' | 'media_hash' | 'conflict';
  category?: string;
  status?: 'authentic' | 'manipulated' | 'synthetic' | 'disputed' | 'neutral';
  details?: string;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
}

export type RelationType = 
  | 'SHARES_MEDIA' 
  | 'CONTRADICTS' 
  | 'TEMPORAL_MISMATCH' 
  | 'COORDINATED_ECHO' 
  | 'CONFIRMS' 
  | 'DERIVED_FROM';

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  relation: RelationType;
  label: string;
  weight?: number;
  isConflict?: boolean;
}

export interface ClassificationMetrics {
  crossArtifactAlignment: number; // 0-100
  temporalCoherence: number; // 0-100
  visualForensicPurity: number; // 0-100
  sourceDispersion: number; // 0-100
}

export interface ClassificationResult {
  verdict: 'AUTHENTIC' | 'MANIPULATED' | 'COORDINATED SYNTHETIC';
  confidence: number;
  summary: string;
  verdictDetails: string;
  metrics: ClassificationMetrics;
  evidence: EvidenceItem[];
  uncertainties: UncertaintyItem[];
  graph: {
    nodes: GraphNode[];
    edges: GraphEdge[];
  };
  crossReasoningInsights: {
    crossCorroboration: string;
    temporalAnomalies: string[];
    networkCoordination: string;
    syntheticFingerprintNotes: string;
  };
  analyzedAt: string;
}

export interface UnseenPatternBenchmark {
  id: string;
  name: string;
  category: string;
  difficulty: 'High' | 'Extreme' | 'Zero-Day';
  description: string;
  unseenTechnique: string;
  expectedVerdict: 'AUTHENTIC' | 'MANIPULATED' | 'COORDINATED SYNTHETIC';
  artifacts: Artifact[];
  evaluationResult?: {
    predictedVerdict: 'AUTHENTIC' | 'MANIPULATED' | 'COORDINATED SYNTHETIC';
    confidence: number;
    passed: boolean;
    latencyMs: number;
    detectionExplanation: string;
    resilienceScore: number;
  };
}

export interface InvestigationCase {
  id: string;
  title: string;
  category: string;
  description: string;
  threatLevel: 'Critical' | 'Elevated' | 'Verified Safe';
  thumbnail: string;
  artifacts: Artifact[];
  precomputedAnalysis?: ClassificationResult;
}
