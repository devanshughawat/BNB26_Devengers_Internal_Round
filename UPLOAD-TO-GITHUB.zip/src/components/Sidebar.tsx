import React from 'react';
import { 
  LayoutDashboard, 
  Search, 
  Share2, 
  FolderGit2, 
  Bell, 
  UploadCloud, 
  FileBarChart, 
  Settings,
  ShieldAlert,
  FlaskConical,
  Download
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  unreadAlertsCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  unreadAlertsCount = 3,
}) => {
  return (
    <aside className="w-60 bg-[#0D111A] border-r border-[#161D2B] flex flex-col h-screen sticky top-0 select-none z-20">
      {/* Brand Header */}
      <div className="p-4 flex items-center space-x-3 border-b border-[#161D2B]">
        <div className="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center shadow-md shadow-sky-600/30 font-black text-white text-base">
          T
        </div>
        <div>
          <h1 className="text-sm font-bold text-white tracking-tight leading-tight">
            TruthLens AI
          </h1>
          <p className="text-[10px] text-slate-400 font-mono tracking-tight">
            Authenticity Intelligence
          </p>
        </div>
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 py-4 px-3 space-y-6 overflow-y-auto">
        {/* MAIN Section */}
        <div>
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 px-3 block mb-1.5 font-medium">
            Main
          </span>
          <nav className="space-y-0.5">
            <button
              onClick={() => onSelectTab('overview')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'overview'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Overview</span>
            </button>

            <button
              onClick={() => onSelectTab('investigations')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'investigations'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <Search className="w-4 h-4" />
              <span>Investigations</span>
            </button>

            <button
              onClick={() => onSelectTab('networks')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'networks'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <Share2 className="w-4 h-4" />
              <span>Account Networks</span>
            </button>

            <button
              onClick={() => onSelectTab('library')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'library'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <FolderGit2 className="w-4 h-4" />
              <span>Content Library</span>
            </button>

            <button
              onClick={() => onSelectTab('alerts')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'alerts'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Bell className="w-4 h-4" />
                <span>Alerts</span>
              </div>
              <span className="w-2 h-2 rounded-full bg-rose-500 ring-2 ring-rose-500/20" />
            </button>
          </nav>
        </div>

        {/* ANALYSIS Section */}
        <div>
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 px-3 block mb-1.5 font-medium">
            Analysis
          </span>
          <nav className="space-y-0.5">
            <button
              onClick={() => onSelectTab('submit')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'submit'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <UploadCloud className="w-4 h-4" />
              <span>Submit Content</span>
            </button>

            <button
              onClick={() => onSelectTab('benchmark')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'benchmark'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <FlaskConical className="w-4 h-4" />
              <span>Unseen Benchmark</span>
            </button>

            <button
              onClick={() => onSelectTab('reports')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'reports'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <FileBarChart className="w-4 h-4" />
              <span>Reports</span>
            </button>

            <button
              onClick={() => onSelectTab('settings')}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium transition ${
                currentTab === 'settings'
                  ? 'bg-[#19243C] text-sky-400 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#131926]'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>

            <a
              href="/api/download-zip"
              download="truthlens-ai-project.zip"
              className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-[#131926] transition"
              title="Download complete source code ZIP"
            >
              <Download className="w-4 h-4 text-sky-400" />
              <span>Download ZIP</span>
            </a>
          </nav>
        </div>
      </div>

      {/* Footer System Status */}
      <div className="p-3 border-t border-[#161D2B] bg-[#0A0D14]/60">
        <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Core AI Engine: Online</span>
        </div>
      </div>
    </aside>
  );
};
