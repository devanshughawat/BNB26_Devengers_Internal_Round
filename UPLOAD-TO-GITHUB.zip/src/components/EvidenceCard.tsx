import React from 'react';
import { EvidenceItem } from '../types/forensic';
import { Check, AlertCircle, Sparkles, Clock, Share2, Eye, ShieldAlert, Cpu } from 'lucide-react';

interface EvidenceCardProps {
  item: EvidenceItem;
  index: number;
  onHighlightArtifacts?: (artifactIds: string[]) => void;
}

export const EvidenceCard: React.FC<EvidenceCardProps> = ({ item, index, onHighlightArtifacts }) => {
  const getCategoryIcon = (category: EvidenceItem['category']) => {
    switch (category) {
      case 'visual_match':
        return <Eye className="w-4 h-4 text-cyan-400" />;
      case 'temporal_mismatch':
        return <Clock className="w-4 h-4 text-amber-400" />;
      case 'cross_post_repetition':
        return <Share2 className="w-4 h-4 text-purple-400" />;
      case 'metadata_conflict':
        return <AlertCircle className="w-4 h-4 text-rose-400" />;
      case 'narrative_contradiction':
        return <ShieldAlert className="w-4 h-4 text-red-400" />;
      case 'ai_synthesis':
        return <Cpu className="w-4 h-4 text-violet-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-indigo-400" />;
    }
  };

  const isPositive = item.type === 'positive';

  return (
    <div 
      className={`relative group p-4 rounded-xl border transition-all duration-200 ${
        isPositive
          ? 'bg-slate-900/60 border-emerald-900/50 hover:border-emerald-600/60'
          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
      }`}
    >
      <div className="flex items-start space-x-3.5">
        {/* Checkmark or Cross Badge */}
        <div
          className={`flex-shrink-0 w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs mt-0.5 ${
            isPositive
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
          }`}
        >
          {isPositive ? <Check className="w-3.5 h-3.5" /> : '✓'}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h4 className="text-sm font-semibold text-slate-100 flex items-center space-x-2">
              <span>{item.label}</span>
            </h4>

            {/* Impact contribution badge */}
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              +{item.confidenceContribution}% weight
            </span>
          </div>

          <p className="mt-1 text-xs text-slate-300 leading-relaxed font-normal">
            {item.description}
          </p>

          {/* Involved Artifact Pills */}
          {item.artifactsInvolved && item.artifactsInvolved.length > 0 && (
            <div className="mt-2.5 flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">
                Artifacts:
              </span>
              {item.artifactsInvolved.map((artId) => (
                <button
                  key={artId}
                  onClick={() => onHighlightArtifacts && onHighlightArtifacts([artId])}
                  className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800/90 hover:bg-indigo-900/50 text-indigo-300 border border-slate-700 hover:border-indigo-600 transition"
                >
                  #{artId}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
