import React, { useState } from 'react';
import { Artifact, ClassificationResult } from '../types/forensic';
import { SimpleEvidenceGraph } from './SimpleEvidenceGraph';
import { AddArtifactModal } from './AddArtifactModal';
import {
  Sparkles,
  Layers,
  Upload,
  Trash2,
  RefreshCw,
  FileText,
  Image as ImageIcon,
  Check,
  AlertTriangle,
  ArrowLeft,
  Download
} from 'lucide-react';

interface InvestigationViewProps {
  caseTitle: string;
  artifacts: Artifact[];
  result: ClassificationResult | null;
  onBack: () => void;
  onRunAnalysis: () => Promise<void>;
  isAnalyzing: boolean;
  onAddArtifact: (art: Artifact) => void;
  onRemoveArtifact: (id: string) => void;
  onExport: () => void;
}

export const InvestigationView: React.FC<InvestigationViewProps> = ({
  caseTitle,
  artifacts,
  result,
  onBack,
  onRunAnalysis,
  isAnalyzing,
  onAddArtifact,
  onRemoveArtifact,
  onExport,
}) => {
  const [isAddOpen, setIsAddOpen] = useState(false);

  const getArtifactClassification = (artifactId: string) => {
    const status = result?.graph.nodes.find((node) => node.id === artifactId)?.status;

    switch (status) {
      case 'synthetic':
        return { label: 'AI-GENERATED', className: 'bg-purple-950/70 text-purple-300 border-purple-800' };
      case 'authentic':
        return { label: 'ORIGINAL', className: 'bg-emerald-950/70 text-emerald-300 border-emerald-800' };
      case 'manipulated':
        return { label: 'MANIPULATED', className: 'bg-rose-950/70 text-rose-300 border-rose-800' };
      case 'disputed':
        return { label: 'DISPUTED', className: 'bg-amber-950/70 text-amber-300 border-amber-800' };
      default:
        return {
          label: result ? 'UNCLASSIFIED' : 'NOT ANALYZED',
          className: 'bg-slate-800 text-slate-300 border-slate-700',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded-lg bg-[#0F1422] hover:bg-[#141B2D] text-slate-300 border border-[#1A2336] transition"
            title="Back to Overview"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              {caseTitle}
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Multi-Artifact Forensic Reasoning Workspace
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsAddOpen(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#0F1422] hover:bg-[#141B2D] text-slate-300 border border-[#1A2336] transition"
          >
            <Upload className="w-3.5 h-3.5 text-sky-400" />
            <span>Upload Item</span>
          </button>
          {result && (
            <button
              onClick={onExport}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            >
              <Download className="w-3.5 h-3.5 text-sky-400" />
              <span>Export Report</span>
            </button>
          )}
        </div>
      </div>

      {/* Artifacts Shelf */}
      <div className="bg-[#0F1422] border border-[#1A2336] rounded-2xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-sky-400" />
            <h3 className="text-xs font-mono font-bold uppercase text-slate-200">
              Correlated Artifacts ({artifacts.length})
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Analyzed together for cross-corroboration
          </span>
        </div>

        {/* Artifact Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {artifacts.map((art) => {
            const classification = getArtifactClassification(art.id);

            return (
            <div
              key={art.id}
              className="bg-[#0D111A] rounded-xl border border-[#161D2B] p-3 flex flex-col justify-between space-y-2.5 relative group hover:border-[#22304a] transition"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-1.5">
                  {art.mediaUrl ? (
                    <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                  ) : (
                    <FileText className="w-3.5 h-3.5 text-sky-400" />
                  )}
                  <span className="text-[11px] font-semibold text-slate-200 truncate max-w-[130px]">
                    {art.title}
                  </span>
                </div>
                <button
                  onClick={() => onRemoveArtifact(art.id)}
                  className="text-slate-500 hover:text-rose-400 p-0.5 transition"
                  title="Remove item"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <span className={`self-start px-2 py-0.5 rounded border text-[9px] font-mono font-bold tracking-wide ${classification.className}`}>
                {classification.label}
              </span>

              {art.mediaUrl ? (
                <div className="h-24 w-full rounded-lg overflow-hidden bg-slate-950 border border-[#1A2336]">
                  <img src={art.mediaUrl} alt={art.title} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="h-24 p-2 bg-[#0A0D14] rounded-lg border border-[#1A2336] text-[11px] text-slate-300 line-clamp-4 italic">
                  "{art.content}"
                </div>
              )}

              <div className="text-[10px] text-slate-400 flex items-center justify-between border-t border-[#161D2B] pt-1.5 font-mono">
                <span className="truncate max-w-[100px]">{art.source}</span>
                <span>{art.timestamp.split(' ')[0]}</span>
              </div>
            </div>
            );
          })}
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <button
            onClick={onRunAnalysis}
            disabled={isAnalyzing || artifacts.length === 0}
            className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-sky-600/25 transition disabled:opacity-50 flex items-center justify-center space-x-2"
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Running Cross-Content Reasoning &amp; Graph Synthesis...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Run Cross-Artifact Analysis</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Forensic Intelligence Findings */}
      {result && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Classification & Confidence Banner */}
          <div
            className={`rounded-2xl border p-5 sm:p-6 transition-all shadow-xl ${
              result.verdict === 'AUTHENTIC'
                ? 'bg-emerald-950/40 border-emerald-900/60'
                : result.verdict === 'SYNTHETIC' || result.verdict === 'COORDINATED SYNTHETIC'
                ? 'bg-purple-950/40 border-purple-900/60'
                : result.verdict === 'INCONCLUSIVE'
                ? 'bg-amber-950/40 border-amber-900/60'
                : 'bg-rose-950/40 border-rose-900/60'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                  Classification
                </span>
                <div className="flex items-center space-x-3 mt-0.5">
                  <h2
                    className={`text-2xl sm:text-3xl font-black tracking-tight ${
                      result.verdict === 'AUTHENTIC'
                        ? 'text-emerald-400'
                        : result.verdict === 'SYNTHETIC' || result.verdict === 'COORDINATED SYNTHETIC'
                        ? 'text-purple-400'
                        : result.verdict === 'INCONCLUSIVE'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {result.verdict}
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-slate-200 mt-2 max-w-2xl leading-relaxed">
                  {result.summary}
                </p>
              </div>

              <div className="flex-shrink-0 bg-[#0A0D14]/90 rounded-xl px-4 py-3 border border-[#1A2336] text-center min-w-[120px]">
                <span className="text-[10px] uppercase font-mono text-slate-400 block">
                  Confidence
                </span>
                <span className="text-3xl font-black text-white font-mono">
                  {result.confidence}%
                </span>
              </div>
            </div>
          </div>

          {/* Evidence Checklist */}
          <div className="bg-[#0F1422] rounded-2xl border border-[#1A2336] p-5 space-y-3 shadow-xl">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
              Evidence Behind Decision:
            </h3>
            <div className="space-y-2">
              {result.evidence.map((item) => (
                <div
                  key={item.id}
                  className="flex items-start space-x-3 p-3 rounded-xl bg-[#0D111A] border border-[#161D2B]"
                >
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">
                    ✓
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-xs sm:text-sm text-slate-100">
                      {item.label}
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Uncertainty Warnings */}
          {result.uncertainties && result.uncertainties.length > 0 && (
            <div className="bg-amber-950/20 rounded-2xl border border-amber-900/40 p-5 space-y-3">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-2">
                <span>Uncertainty &amp; Conflicting Signals:</span>
              </h3>
              <div className="space-y-2">
                {result.uncertainties.map((u) => (
                  <div
                    key={u.id}
                    className="flex items-start space-x-3 p-3 rounded-xl bg-[#0D111A] border border-amber-900/30"
                  >
                    <span className="text-amber-400 font-bold text-sm mt-0.5">⚠</span>
                    <div className="flex-1">
                      <div className="text-xs sm:text-sm font-semibold text-amber-200">
                        {u.title}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                        {u.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Relationship Graph */}
          <SimpleEvidenceGraph
            nodes={result.graph.nodes}
            edges={result.graph.edges}
          />
        </div>
      )}

      {/* Upload Item Modal */}
      <AddArtifactModal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        onAdd={onAddArtifact}
      />
    </div>
  );
};
