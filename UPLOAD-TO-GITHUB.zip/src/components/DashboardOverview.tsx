import React from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  Plus, 
  Bell, 
  ShieldCheck, 
  AlertTriangle, 
  Cpu, 
  Network, 
  TrendingUp,
  FileCheck2,
  ChevronRight,
  Download
} from 'lucide-react';

export interface FeedDetection {
  id: string;
  badge: 'SYNTHETIC' | 'MANIPULATED' | 'AUTHENTIC';
  title: string;
  subtitle: string;
  timestamp: string;
  caseId?: string;
}

interface DashboardOverviewProps {
  onOpenNewAnalysis: () => void;
  onSelectDetection: (item: FeedDetection) => void;
  onOpenNetworks: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  onOpenNewAnalysis,
  onSelectDetection,
  onOpenNetworks,
}) => {
  const detections: FeedDetection[] = [
    {
      id: 'det-1',
      badge: 'SYNTHETIC',
      title: 'Coordinated narrative cluster detected — 47 accounts',
      subtitle: 'Twitter / X · Campaign #7823 · Confidence 97.2%',
      timestamp: '2m ago',
      caseId: 'case-astroturf-wildfire',
    },
    {
      id: 'det-2',
      badge: 'MANIPULATED',
      title: 'Image miscontextualization: vaccine protest photo reused',
      subtitle: 'Facebook · Image Hash Match 89.1% · 12 posts flagged',
      timestamp: '6m ago',
      caseId: 'case-dam-breach',
    },
    {
      id: 'det-3',
      badge: 'AUTHENTIC',
      title: 'Video analysis complete — 8.2M view breaking news clip verified',
      subtitle: 'YouTube · Deepfake Score 1.3% · Metadata Consistent',
      timestamp: '15m ago',
      caseId: 'case-glacial-collapse',
    },
    {
      id: 'det-4',
      badge: 'SYNTHETIC',
      title: 'AI-generated profile images — 23 accounts in network cluster',
      subtitle: 'Instagram · GAN Detection 94.7% · Cluster ID: C-1142',
      timestamp: '23m ago',
      caseId: 'case-astroturf-wildfire',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Intelligence Overview
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time content authenticity monitoring across all tracked campaigns
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search content, accounts..."
              className="bg-[#0F1422] border border-[#1A2336] rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 w-52 md:w-64 transition"
            />
          </div>

          {/* Filters Button */}
          <button className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#0F1422] hover:bg-[#141B2D] text-slate-300 border border-[#1A2336] transition">
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
            <span>Filters</span>
          </button>

          {/* Download ZIP Button */}
          <a
            href="/api/download-zip"
            download="truthlens-ai-project.zip"
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#0F1422] hover:bg-[#141B2D] text-slate-200 border border-[#1A2336] transition"
            title="Download full project ZIP archive"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>Download ZIP</span>
          </a>

          {/* New Analysis Button */}
          <button
            onClick={onOpenNewAnalysis}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white shadow-md shadow-sky-600/25 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Analysis</span>
          </button>

          {/* Notification Bell */}
          <button className="p-2 rounded-lg bg-[#0F1422] hover:bg-[#141B2D] text-slate-400 hover:text-slate-200 border border-[#1A2336] transition relative">
            <Bell className="w-3.5 h-3.5" />
            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full absolute top-1.5 right-1.5" />
          </button>
        </div>
      </div>

      {/* KPI Stats Row (5 Cards) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        {/* Card 1: Total Analyzed */}
        <div className="bg-[#0F1422] border border-[#1A2336] rounded-xl p-4 space-y-2 hover:border-[#22304a] transition">
          <div className="flex items-center space-x-2 text-slate-400 text-xs font-medium">
            <FileCheck2 className="w-3.5 h-3.5 text-sky-400" />
            <span>Total Analyzed</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            48,291
          </div>
          <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-mono">
            <TrendingUp className="w-3 h-3" />
            <span>+12.4% this week</span>
          </div>
        </div>

        {/* Card 2: Authentic */}
        <div className="bg-[#0F1422] border border-[#1A2336] rounded-xl p-4 space-y-2 hover:border-[#22304a] transition">
          <div className="flex items-center space-x-2 text-slate-400 text-xs font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Authentic</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            31,847
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            65.8% of total content
          </div>
        </div>

        {/* Card 3: Manipulated */}
        <div className="bg-[#0F1422] border border-[#1A2336] rounded-xl p-4 space-y-2 hover:border-[#22304a] transition">
          <div className="flex items-center space-x-2 text-slate-400 text-xs font-medium">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Manipulated</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            11,203
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            23.2% of total content
          </div>
        </div>

        {/* Card 4: Coordinated Synthetic */}
        <div className="bg-[#0F1422] border border-[#1A2336] rounded-xl p-4 space-y-2 hover:border-[#22304a] transition">
          <div className="flex items-center space-x-2 text-slate-400 text-xs font-medium">
            <Cpu className="w-3.5 h-3.5 text-rose-400" />
            <span>Coordinated Synthetic</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            5,241
          </div>
          <div className="flex items-center space-x-1 text-[11px] text-rose-400 font-mono">
            <TrendingUp className="w-3 h-3" />
            <span>+38% — Active Campaign</span>
          </div>
        </div>

        {/* Card 5: Coordinated Clusters */}
        <div className="bg-[#0F1422] border border-[#1A2336] rounded-xl p-4 space-y-2 hover:border-[#22304a] transition cursor-pointer" onClick={onOpenNetworks}>
          <div className="flex items-center space-x-2 text-slate-400 text-xs font-medium">
            <Network className="w-3.5 h-3.5 text-purple-400" />
            <span>Coordinated Clusters</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tracking-tight">
            147
          </div>
          <div className="text-[11px] text-purple-400 font-mono">
            34 high-risk active now
          </div>
        </div>
      </div>

      {/* Live Detection Feed Box */}
      <div className="bg-[#0F1422] border border-[#1A2336] rounded-2xl overflow-hidden shadow-xl">
        {/* Feed Header */}
        <div className="p-4 border-b border-[#1A2336] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <h3 className="text-sm font-bold text-white tracking-tight">
              Live Detection Feed
            </h3>
            <span className="flex items-center space-x-1 px-2 py-0.5 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-mono font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
              <span>LIVE</span>
            </span>
          </div>

          <span className="text-[11px] text-slate-400 font-mono">
            Auto-refresh: 5s
          </span>
        </div>

        {/* Feed List Items */}
        <div className="divide-y divide-[#161D2B]">
          {detections.map((item) => {
            const isSynthetic = item.badge === 'SYNTHETIC';
            const isManipulated = item.badge === 'MANIPULATED';
            const isAuthentic = item.badge === 'AUTHENTIC';

            return (
              <div
                key={item.id}
                onClick={() => onSelectDetection(item)}
                className="p-4 flex items-center justify-between hover:bg-[#141B2D]/70 cursor-pointer transition group"
              >
                <div className="flex items-center space-x-3.5">
                  {/* Badge */}
                  <span
                    className={`px-2.5 py-1 rounded-md text-[10px] font-mono font-bold uppercase tracking-wider ${
                      isSynthetic
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-800/80'
                        : isManipulated
                        ? 'bg-amber-950/80 text-amber-300 border border-amber-800/80'
                        : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/80'
                    }`}
                  >
                    {item.badge}
                  </span>

                  <div>
                    <h4 className="text-xs font-semibold text-slate-100 group-hover:text-sky-300 transition">
                      {item.title}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
                      {item.subtitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-3 text-xs font-mono text-slate-400">
                  <span>{item.timestamp}</span>
                  <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-transform group-hover:translate-x-0.5" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Feed Footer */}
        <div className="p-3 bg-[#0D111A]/80 border-t border-[#161D2B] text-center">
          <button
            onClick={onOpenNewAnalysis}
            className="text-xs font-medium text-sky-400 hover:text-sky-300 transition inline-flex items-center space-x-1"
          >
            <span>View all 2,847 detections →</span>
          </button>
        </div>
      </div>
    </div>
  );
};
