import React from 'react';
import { ClassificationResult, Artifact } from '../types/forensic';
import { X, Download, Printer, ShieldCheck, Copy, Check } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: ClassificationResult;
  artifacts: Artifact[];
  caseTitle: string;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  result,
  artifacts,
  caseTitle,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const exportData = {
    caseTitle,
    generatedAt: new Date().toISOString(),
    verdict: result.verdict,
    confidence: `${result.confidence}%`,
    summary: result.summary,
    artifacts: artifacts.map((a) => ({
      id: a.id,
      type: a.type,
      title: a.title,
      source: a.source,
      timestamp: a.timestamp,
      metadata: a.metadata,
    })),
    evidence: result.evidence,
    uncertainties: result.uncertainties,
    graphTopology: {
      nodeCount: result.graph.nodes.length,
      edgeCount: result.graph.edges.length,
      relations: result.graph.edges.map((e) => ({
        source: e.source,
        target: e.target,
        relation: e.relation,
      })),
    },
    metrics: result.metrics,
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(exportData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TruthLens_Forensic_Dossier_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 text-slate-200 shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="text-base font-bold text-white">Forensic Intelligence Export</h3>
              <p className="text-xs text-slate-400">
                Official Chain of Custody &amp; Disinformation Assessment Brief
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Executive Summary Preview */}
        <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase font-mono">{caseTitle}</span>
            <span
              className={`text-xs font-mono font-bold px-2 py-0.5 rounded border uppercase ${
                result.verdict === 'AUTHENTIC'
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  : result.verdict === 'SYNTHETIC' || result.verdict === 'COORDINATED SYNTHETIC'
                  ? 'bg-purple-950 text-purple-300 border-purple-800'
                  : result.verdict === 'INCONCLUSIVE'
                  ? 'bg-amber-950 text-amber-300 border-amber-800'
                  : 'bg-red-950 text-red-300 border-red-800'
              }`}
            >
              {result.verdict} ({result.confidence}%)
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-mono">
            {result.summary}
          </p>
        </div>

        {/* JSON Preview */}
        <div>
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-1">
            Machine-Readable Dossier Payload
          </span>
          <pre className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-300 font-mono max-h-56 overflow-y-auto leading-relaxed">
            {JSON.stringify(exportData, null, 2)}
          </pre>
        </div>

        {/* Actions */}
        <div className="pt-2 flex items-center justify-end space-x-2">
          <button
            onClick={handleCopyJson}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy JSON'}</span>
          </button>

          <button
            onClick={handleDownloadJson}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .JSON</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};
