import React, { useMemo } from 'react';
import { GraphNode, GraphEdge } from '../types/forensic';

interface SimpleEvidenceGraphProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export const SimpleEvidenceGraph: React.FC<SimpleEvidenceGraphProps> = ({ nodes, edges }) => {
  // Compute clean positions for a clear, readable diagram
  const { nodePositions, width, height } = useMemo(() => {
    const w = 700;
    const h = 340;
    const pos = new Map<string, { x: number; y: number }>();

    if (!nodes || nodes.length === 0) return { nodePositions: pos, width: w, height: h };

    const artifacts = nodes.filter((n) => n.type === 'artifact');
    const others = nodes.filter((n) => n.type !== 'artifact');

    // Place artifacts on the left side
    const artCount = artifacts.length;
    artifacts.forEach((node, i) => {
      const y = (h / (artCount + 1)) * (i + 1);
      pos.set(node.id, { x: 140, y });
    });

    // Place central / other nodes on the right side
    const otherCount = others.length;
    others.forEach((node, i) => {
      const y = (h / (otherCount + 1)) * (i + 1);
      pos.set(node.id, { x: 520, y });
    });

    return { nodePositions: pos, width: w, height: h };
  }, [nodes]);

  const getNodeColor = (node: GraphNode) => {
    if (node.status === 'authentic') return { fill: '#064e3b', stroke: '#10b981', text: '#34d399' };
    if (node.status === 'manipulated') return { fill: '#4c0519', stroke: '#f43f5e', text: '#fb7185' };
    if (node.status === 'synthetic') return { fill: '#3b0764', stroke: '#a855f7', text: '#c084fc' };
    return { fill: '#451a03', stroke: '#f59e0b', text: '#fbbf24' };
  };

  const getEdgeStyle = (edge: GraphEdge) => {
    if (edge.relation === 'CONTRADICTS' || edge.isConflict) {
      return { stroke: '#f43f5e', strokeDasharray: '4 4', strokeWidth: 2, labelBg: '#4c0519', labelText: '#fca5a5' };
    }
    if (edge.relation === 'SHARES_MEDIA') {
      return { stroke: '#06b6d4', strokeDasharray: 'none', strokeWidth: 2, labelBg: '#164e63', labelText: '#67e8f9' };
    }
    if (edge.relation === 'TEMPORAL_MISMATCH') {
      return { stroke: '#f59e0b', strokeDasharray: '4 4', strokeWidth: 2, labelBg: '#451a03', labelText: '#fde68a' };
    }
    if (edge.relation === 'COORDINATED_ECHO') {
      return { stroke: '#a855f7', strokeDasharray: '2 2', strokeWidth: 2, labelBg: '#3b0764', labelText: '#d8b4fe' };
    }
    return { stroke: '#10b981', strokeDasharray: 'none', strokeWidth: 1.5, labelBg: '#064e3b', labelText: '#6ee7b7' };
  };

  return (
    <div className="w-full bg-slate-900/60 rounded-xl border border-slate-800 p-3 overflow-hidden">
      <div className="flex items-center justify-between pb-2 text-xs text-slate-400 border-b border-slate-800/80 mb-2">
        <span className="font-semibold text-slate-300">🕸️ Evidence &amp; Connection Map</span>
        <div className="flex items-center space-x-3 text-[11px]">
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-rose-500 inline-block" />
            <span>Contradiction</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-cyan-400 inline-block" />
            <span>Shared Image</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
            <span>Confirms</span>
          </span>
        </div>
      </div>

      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none" style={{ maxHeight: '340px' }}>
        {/* Draw Edges */}
        {edges.map((edge) => {
          const from = nodePositions.get(edge.source);
          const to = nodePositions.get(edge.target);
          if (!from || !to) return null;

          const style = getEdgeStyle(edge);
          const midX = (from.x + to.x) / 2;
          const midY = (from.y + to.y) / 2;

          return (
            <g key={edge.id}>
              <line
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
                stroke={style.stroke}
                strokeWidth={style.strokeWidth}
                strokeDasharray={style.strokeDasharray}
              />
              {edge.label && (
                <g transform={`translate(${midX}, ${midY})`}>
                  <rect
                    x={-edge.label.length * 3 - 6}
                    y="-9"
                    width={edge.label.length * 6 + 12}
                    height="18"
                    rx="9"
                    fill={style.labelBg}
                    stroke={style.stroke}
                    strokeWidth="0.8"
                  />
                  <text
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill={style.labelText}
                    fontSize="9"
                    fontWeight="500"
                  >
                    {edge.label}
                  </text>
                </g>
              )}
            </g>
          );
        })}

        {/* Draw Nodes */}
        {nodes.map((node) => {
          const pos = nodePositions.get(node.id);
          if (!pos) return null;

          const color = getNodeColor(node);
          const label = node.label.length > 22 ? node.label.slice(0, 20) + '...' : node.label;

          return (
            <g key={node.id} transform={`translate(${pos.x}, ${pos.y})`}>
              <rect
                x="-80"
                y="-18"
                width="160"
                height="36"
                rx="18"
                fill={color.fill}
                stroke={color.stroke}
                strokeWidth="1.5"
              />
              <text
                textAnchor="middle"
                dominantBaseline="middle"
                fill="#ffffff"
                fontSize="11"
                fontWeight="600"
              >
                {label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};
