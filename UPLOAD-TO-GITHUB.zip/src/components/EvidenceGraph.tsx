import React, { useState, useEffect, useRef, useMemo } from 'react';
import { GraphNode, GraphEdge, RelationType } from '../types/forensic';
import { 
  Network, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  AlertTriangle, 
  Share2, 
  Clock, 
  Layers, 
  CheckCircle2, 
  FileText, 
  Image, 
  Video, 
  X,
  Info,
  Filter
} from 'lucide-react';

interface EvidenceGraphProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
  onSelectNode?: (nodeId: string) => void;
  selectedNodeId?: string | null;
  height?: string | number;
}

export const EvidenceGraph: React.FC<EvidenceGraphProps> = ({
  nodes,
  edges,
  onSelectNode,
  selectedNodeId,
  height = '580px',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [activeFilter, setActiveFilter] = useState<'all' | 'conflicts' | 'media' | 'temporal' | 'coordination'>('all');
  const [inspectedNode, setInspectedNode] = useState<GraphNode | null>(null);

  // Position nodes nicely using a deterministic layout (circular / bipartite)
  const nodePositions = useMemo(() => {
    const posMap = new Map<string, { x: number; y: number }>();
    if (!nodes || nodes.length === 0) return posMap;

    const width = 800;
    const heightVal = 500;
    const centerX = width / 2;
    const centerY = heightVal / 2;

    // Group nodes: artifacts on left/outer circle, claims/conflicts in center/right
    const artifacts = nodes.filter((n) => n.type === 'artifact');
    const others = nodes.filter((n) => n.type !== 'artifact');

    // Layout artifacts on an outer arc/circle
    const radius = Math.min(centerX, centerY) - 80;
    artifacts.forEach((node, i) => {
      const angle = (i / Math.max(1, artifacts.length)) * 2 * Math.PI - Math.PI / 2;
      posMap.set(node.id, {
        x: centerX + radius * Math.cos(angle) * 0.95,
        y: centerY + radius * Math.sin(angle) * 0.75,
      });
    });

    // Layout other nodes (claims, media hashes, conflicts) in the core
    others.forEach((node, i) => {
      const innerRadius = 90;
      const angle = (i / Math.max(1, others.length)) * 2 * Math.PI;
      posMap.set(node.id, {
        x: centerX + (others.length > 1 ? innerRadius * Math.cos(angle) : 0),
        y: centerY + (others.length > 1 ? innerRadius * Math.sin(angle) * 0.7 : 0),
      });
    });

    return posMap;
  }, [nodes]);

  // Handle filtering
  const filteredEdges = useMemo(() => {
    if (!edges) return [];
    if (activeFilter === 'all') return edges;
    if (activeFilter === 'conflicts') return edges.filter((e) => e.isConflict || e.relation === 'CONTRADICTS');
    if (activeFilter === 'media') return edges.filter((e) => e.relation === 'SHARES_MEDIA');
    if (activeFilter === 'temporal') return edges.filter((e) => e.relation === 'TEMPORAL_MISMATCH');
    if (activeFilter === 'coordination') return edges.filter((e) => e.relation === 'COORDINATED_ECHO');
    return edges;
  }, [edges, activeFilter]);

  // Pan controls
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).tagName.toLowerCase() === 'svg' || (e.target as HTMLElement).id === 'graph-canvas') {
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Node Click
  const handleNodeClick = (node: GraphNode) => {
    setInspectedNode(node);
    if (onSelectNode) onSelectNode(node.id);
  };

  // Node styling helpers
  const getNodeColor = (node: GraphNode) => {
    if (node.status === 'authentic') return { bg: '#064e3b', border: '#10b981', text: '#34d399' };
    if (node.status === 'manipulated') return { bg: '#7f1d1d', border: '#ef4444', text: '#f87171' };
    if (node.status === 'synthetic') return { bg: '#581c87', border: '#a855f7', text: '#c084fc' };
    if (node.status === 'disputed' || node.type === 'conflict') return { bg: '#78350f', border: '#f59e0b', text: '#fbbf24' };
    return { bg: '#1e293b', border: '#64748b', text: '#94a3b8' };
  };

  // Edge styling helpers
  const getEdgeAttributes = (edge: GraphEdge) => {
    switch (edge.relation) {
      case 'CONTRADICTS':
        return { stroke: '#ef4444', strokeDasharray: '5,5', strokeWidth: 2.5, glow: 'rgba(239, 68, 68, 0.4)' };
      case 'SHARES_MEDIA':
        return { stroke: '#06b6d4', strokeDasharray: 'none', strokeWidth: 2.5, glow: 'rgba(6, 182, 212, 0.4)' };
      case 'TEMPORAL_MISMATCH':
        return { stroke: '#f59e0b', strokeDasharray: '6,4', strokeWidth: 2, glow: 'rgba(245, 158, 11, 0.3)' };
      case 'COORDINATED_ECHO':
        return { stroke: '#a855f7', strokeDasharray: '3,3', strokeWidth: 2.5, glow: 'rgba(168, 85, 247, 0.5)' };
      case 'CONFIRMS':
        return { stroke: '#10b981', strokeDasharray: 'none', strokeWidth: 2, glow: 'rgba(16, 185, 129, 0.3)' };
      case 'DERIVED_FROM':
      default:
        return { stroke: '#475569', strokeDasharray: 'none', strokeWidth: 1.5, glow: 'transparent' };
    }
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden select-none"
      style={{ height }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* HUD Header Bar */}
      <div className="absolute top-4 left-4 z-20 flex items-center space-x-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-300 shadow-lg">
        <Network className="w-4 h-4 text-indigo-400" />
        <span className="font-semibold text-slate-100">NetworkX Evidence Graph</span>
        <span className="text-slate-500">|</span>
        <span className="font-mono text-[11px] text-slate-400">
          {nodes.length} Nodes • {filteredEdges.length} Edges
        </span>
      </div>

      {/* Filter Chips Bar */}
      <div className="absolute top-4 right-4 z-20 flex items-center space-x-1 bg-slate-900/90 backdrop-blur-md p-1 rounded-xl border border-slate-800 shadow-lg text-xs">
        <button
          onClick={() => setActiveFilter('all')}
          className={`px-2.5 py-1 rounded-lg transition ${
            activeFilter === 'all' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setActiveFilter('conflicts')}
          className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition ${
            activeFilter === 'conflicts' ? 'bg-red-600 text-white font-medium' : 'text-red-400 hover:bg-red-950/40'
          }`}
        >
          <AlertTriangle className="w-3 h-3" />
          <span>Conflicts</span>
        </button>
        <button
          onClick={() => setActiveFilter('media')}
          className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition ${
            activeFilter === 'media' ? 'bg-cyan-600 text-white font-medium' : 'text-cyan-400 hover:bg-cyan-950/40'
          }`}
        >
          <Share2 className="w-3 h-3" />
          <span>Shared Media</span>
        </button>
        <button
          onClick={() => setActiveFilter('temporal')}
          className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition ${
            activeFilter === 'temporal' ? 'bg-amber-600 text-white font-medium' : 'text-amber-400 hover:bg-amber-950/40'
          }`}
        >
          <Clock className="w-3 h-3" />
          <span>Temporal</span>
        </button>
        <button
          onClick={() => setActiveFilter('coordination')}
          className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg transition ${
            activeFilter === 'coordination' ? 'bg-purple-600 text-white font-medium' : 'text-purple-400 hover:bg-purple-950/40'
          }`}
        >
          <Layers className="w-3 h-3" />
          <span>Bot Synchrony</span>
        </button>
      </div>

      {/* Floating Zoom & Center Controls */}
      <div className="absolute bottom-4 right-4 z-20 flex flex-col space-y-1 bg-slate-900/90 backdrop-blur-md p-1 rounded-xl border border-slate-800 shadow-lg text-slate-300">
        <button
          onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))}
          className="p-1.5 hover:bg-slate-800 rounded-lg transition"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))}
          className="p-1.5 hover:bg-slate-800 rounded-lg transition"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={resetView}
          className="p-1.5 hover:bg-slate-800 rounded-lg transition"
          title="Reset View"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>

      {/* Legend Bar */}
      <div className="absolute bottom-4 left-4 z-20 hidden md:flex items-center space-x-4 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
        <div className="flex items-center space-x-1.5">
          <span className="w-2.5 h-0.5 bg-red-500 inline-block border-b border-red-500 border-dashed" />
          <span>Contradiction</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-2.5 h-0.5 bg-cyan-400 inline-block" />
          <span>Shares Media</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-2.5 h-0.5 bg-amber-400 inline-block border-b border-amber-400 border-dashed" />
          <span>Date Mismatch</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-2.5 h-0.5 bg-purple-500 inline-block" />
          <span>Coordinated Echo</span>
        </div>
        <div className="flex items-center space-x-1.5">
          <span className="w-2.5 h-0.5 bg-emerald-500 inline-block" />
          <span>Corroborates</span>
        </div>
      </div>

      {/* SVG Canvas */}
      <svg
        id="graph-canvas"
        className="w-full h-full cursor-grab active:cursor-grabbing"
        viewBox="0 0 800 500"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          {/* Arrow markers */}
          <marker id="arrow-gray" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#64748b" />
          </marker>
          <marker id="arrow-red" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#ef4444" />
          </marker>
          <marker id="arrow-cyan" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#06b6d4" />
          </marker>
          <marker id="arrow-purple" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#a855f7" />
          </marker>

          {/* Grid pattern */}
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <circle cx="20" cy="20" r="1" fill="#334155" opacity="0.4" />
          </pattern>
        </defs>

        <rect width="100%" height="100%" fill="url(#grid)" />

        <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
          {/* Edges */}
          {filteredEdges.map((edge) => {
            const srcPos = nodePositions.get(edge.source);
            const tgtPos = nodePositions.get(edge.target);
            if (!srcPos || !tgtPos) return null;

            const edgeAttrs = getEdgeAttributes(edge);
            const isHoveredOrConnected =
              inspectedNode && (inspectedNode.id === edge.source || inspectedNode.id === edge.target);

            // Calculate midpoint for edge label
            const midX = (srcPos.x + tgtPos.x) / 2;
            const midY = (srcPos.y + tgtPos.y) / 2;

            return (
              <g key={edge.id} className="transition-all duration-300">
                {/* Glow underlay if conflict or highlighted */}
                {(edge.isConflict || isHoveredOrConnected) && (
                  <line
                    x1={srcPos.x}
                    y1={srcPos.y}
                    x2={tgtPos.x}
                    y2={tgtPos.y}
                    stroke={edgeAttrs.stroke}
                    strokeWidth={edgeAttrs.strokeWidth + 5}
                    opacity="0.3"
                  />
                )}

                {/* Main line */}
                <line
                  x1={srcPos.x}
                  y1={srcPos.y}
                  x2={tgtPos.x}
                  y2={tgtPos.y}
                  stroke={edgeAttrs.stroke}
                  strokeWidth={isHoveredOrConnected ? edgeAttrs.strokeWidth + 1.5 : edgeAttrs.strokeWidth}
                  strokeDasharray={edgeAttrs.strokeDasharray}
                  markerEnd={`url(#${edge.isConflict ? 'arrow-red' : edge.relation === 'SHARES_MEDIA' ? 'arrow-cyan' : 'arrow-gray'})`}
                />

                {/* Edge Label Pill */}
                {edge.label && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <rect
                      x={-edge.label.length * 3.2 - 6}
                      y="-9"
                      width={edge.label.length * 6.4 + 12}
                      height="18"
                      rx="9"
                      fill="#0f172a"
                      stroke={edgeAttrs.stroke}
                      strokeWidth="1"
                      opacity="0.95"
                    />
                    <text
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fill={edgeAttrs.stroke}
                      fontSize="9"
                      fontFamily="monospace"
                      fontWeight="500"
                    >
                      {edge.label}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Nodes */}
          {nodes.map((node) => {
            const pos = nodePositions.get(node.id);
            if (!pos) return null;

            const isSelected = selectedNodeId === node.id || inspectedNode?.id === node.id;
            const colors = getNodeColor(node);

            return (
              <g
                key={node.id}
                transform={`translate(${pos.x}, ${pos.y})`}
                onClick={() => handleNodeClick(node)}
                className="cursor-pointer transition-transform duration-200 hover:scale-105"
              >
                {/* Highlight ring if selected */}
                {isSelected && (
                  <circle
                    r="34"
                    fill="none"
                    stroke={colors.border}
                    strokeWidth="2.5"
                    strokeDasharray="4,4"
                    className="animate-spin-slow"
                  />
                )}

                {/* Node Shape */}
                {node.type === 'artifact' ? (
                  // Hexagon or Rounded Rect for artifacts
                  <rect
                    x="-24"
                    y="-24"
                    width="48"
                    height="48"
                    rx="14"
                    fill={colors.bg}
                    stroke={colors.border}
                    strokeWidth={isSelected ? 3 : 2}
                    className="shadow-xl"
                  />
                ) : node.type === 'conflict' ? (
                  // Rotated diamond / triangle for conflicts
                  <polygon
                    points="0,-26 26,0 0,26 -26,0"
                    fill={colors.bg}
                    stroke={colors.border}
                    strokeWidth={isSelected ? 3 : 2}
                  />
                ) : (
                  // Circle for claims & media hashes
                  <circle
                    r="22"
                    fill={colors.bg}
                    stroke={colors.border}
                    strokeWidth={isSelected ? 3 : 2}
                  />
                )}

                {/* Icon inside node */}
                <g transform="translate(-8, -8)" pointerEvents="none">
                  {node.type === 'artifact' ? (
                    <FileText className="w-4 h-4 text-slate-100" />
                  ) : node.type === 'conflict' ? (
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                  ) : node.type === 'media_hash' ? (
                    <Image className="w-4 h-4 text-cyan-400" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  )}
                </g>

                {/* Label text */}
                <text
                  y="36"
                  textAnchor="middle"
                  fill="#f1f5f9"
                  fontSize="11"
                  fontWeight="600"
                  fontFamily="system-ui"
                  className="filter drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]"
                >
                  {node.label.length > 20 ? node.label.slice(0, 18) + '...' : node.label}
                </text>

                {/* Status Subtitle */}
                <text
                  y="48"
                  textAnchor="middle"
                  fill={colors.text}
                  fontSize="8.5"
                  fontFamily="monospace"
                  className="uppercase"
                >
                  {node.status || node.type}
                </text>
              </g>
            );
          })}
        </g>
      </svg>

      {/* Node Inspector Drawer */}
      {inspectedNode && (
        <div className="absolute top-16 right-4 z-30 w-80 bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-700 shadow-2xl p-4 text-slate-200 animate-in fade-in slide-in-from-right-4 duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                inspectedNode.status === 'authentic' ? 'bg-emerald-400' :
                inspectedNode.status === 'synthetic' ? 'bg-purple-400' :
                inspectedNode.status === 'manipulated' ? 'bg-red-400' : 'bg-amber-400'
              }`} />
              <span className="font-semibold text-sm text-slate-100">{inspectedNode.label}</span>
            </div>
            <button
              onClick={() => setInspectedNode(null)}
              className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="py-3 space-y-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-mono tracking-wider">Node Type</span>
              <span className="font-mono text-slate-200 capitalize">{inspectedNode.type}</span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-mono tracking-wider">Forensic Status</span>
              <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-mono font-medium uppercase mt-0.5 ${
                inspectedNode.status === 'authentic' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                inspectedNode.status === 'synthetic' ? 'bg-purple-950 text-purple-300 border border-purple-800' :
                inspectedNode.status === 'manipulated' ? 'bg-red-950 text-red-300 border border-red-800' :
                'bg-amber-950 text-amber-300 border border-amber-800'
              }`}>
                {inspectedNode.status || 'Verified'}
              </span>
            </div>

            {inspectedNode.details && (
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-mono tracking-wider">Forensic Evidence Details</span>
                <p className="text-slate-300 mt-1 leading-relaxed bg-slate-950/60 p-2 rounded-lg border border-slate-800/80">
                  {inspectedNode.details}
                </p>
              </div>
            )}

            {/* Connected Edges Breakdown */}
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-mono tracking-wider">Connected Relations</span>
              <div className="mt-1 space-y-1">
                {edges
                  .filter((e) => e.source === inspectedNode.id || e.target === inspectedNode.id)
                  .map((e) => (
                    <div
                      key={e.id}
                      className="flex items-center justify-between text-[11px] p-1.5 rounded bg-slate-950/40 border border-slate-800"
                    >
                      <span className="font-mono text-indigo-300">{e.relation}</span>
                      <span className="text-slate-400 truncate max-w-[140px]">{e.label}</span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
