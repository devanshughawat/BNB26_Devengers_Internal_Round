import React from 'react';
import { UncertaintyItem } from '../types/forensic';
import { AlertTriangle, HelpCircle, ShieldQuestion, ArrowRight } from 'lucide-react';

interface UncertaintyBannerProps {
  uncertainties: UncertaintyItem[];
}

export const UncertaintyBanner: React.FC<UncertaintyBannerProps> = ({ uncertainties }) => {
  if (!uncertainties || uncertainties.length === 0) return null;

  return (
    <div className="rounded-2xl bg-amber-950/20 border border-amber-900/40 p-4 space-y-3">
      <div className="flex items-center space-x-2 text-amber-400">
        <AlertTriangle className="w-4 h-4 text-amber-400" />
        <span className="text-xs font-semibold uppercase tracking-wider font-mono">
          Uncertainty &amp; Conflicting Signal Detection ({uncertainties.length})
        </span>
      </div>

      <div className="space-y-2.5">
        {uncertainties.map((item) => {
          const isHigh = item.impact === 'high';
          const isMed = item.impact === 'medium';

          return (
            <div
              key={item.id}
              className="bg-slate-950/70 rounded-xl p-3.5 border border-amber-900/30 flex items-start space-x-3"
            >
              <span className="text-amber-400 font-bold text-sm mt-0.5">⚠</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <h5 className="text-xs font-semibold text-amber-200">
                    {item.title}
                  </h5>
                  <span
                    className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
                      isHigh
                        ? 'bg-rose-950/80 text-rose-300 border-rose-800'
                        : isMed
                        ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    {item.impact} impact
                  </span>
                </div>

                <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                  {item.description}
                </p>

                {item.mitigation && (
                  <div className="mt-2 text-[11px] text-slate-400 flex items-start space-x-1.5 bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                    <ArrowRight className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <span>
                      <strong className="text-amber-300/90 font-medium">Forensic Mitigation:</strong>{' '}
                      {item.mitigation}
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
