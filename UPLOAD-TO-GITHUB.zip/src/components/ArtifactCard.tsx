import React, { useState } from 'react';
import { Artifact } from '../types/forensic';
import { 
  FileText, 
  Image as ImageIcon, 
  Video, 
  Globe, 
  Maximize2, 
  Trash2, 
  Clock, 
  Fingerprint, 
  Camera, 
  Cpu, 
  AlertCircle,
  X
} from 'lucide-react';

interface ArtifactCardProps {
  artifact: Artifact;
  onRemove?: (id: string) => void;
  index: number;
}

export const ArtifactCard: React.FC<ArtifactCardProps> = ({ artifact, onRemove, index }) => {
  const [showDetail, setShowDetail] = useState(false);

  const getTypeIcon = () => {
    switch (artifact.type) {
      case 'image':
      case 'screenshot':
        return <ImageIcon className="w-4 h-4 text-cyan-400" />;
      case 'video':
        return <Video className="w-4 h-4 text-purple-400" />;
      case 'article':
      case 'url':
        return <Globe className="w-4 h-4 text-emerald-400" />;
      case 'post':
      default:
        return <FileText className="w-4 h-4 text-indigo-400" />;
    }
  };

  const hasSyntheticClues = (artifact.individualAnalysis?.syntheticClues?.length || 0) > 0;
  const isSuspicious = artifact.individualAnalysis?.metadataIntegrity === 'suspicious' || artifact.individualAnalysis?.metadataIntegrity === 'modified';

  return (
    <>
      <div className="bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-3.5 transition-all duration-200 group flex flex-col justify-between space-y-3">
        {/* Top Header */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-slate-800 border border-slate-700/80">
              {getTypeIcon()}
            </span>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-[10px] font-mono text-indigo-400 font-semibold uppercase">
                  #{artifact.id}
                </span>
                <span className="text-[10px] text-slate-500">•</span>
                <span className="text-[10px] text-slate-400 font-mono capitalize">
                  {artifact.type}
                </span>
              </div>
              <h4 className="text-xs font-semibold text-slate-100 line-clamp-1">
                {artifact.title}
              </h4>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-1">
            <button
              onClick={() => setShowDetail(true)}
              className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
              title="Inspect Full Forensic Metadata"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            {onRemove && (
              <button
                onClick={() => onRemove(artifact.id)}
                className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                title="Remove Artifact"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Media or Text Preview */}
        {artifact.mediaUrl ? (
          <div 
            onClick={() => setShowDetail(true)}
            className="relative h-28 w-full rounded-lg overflow-hidden bg-slate-950 border border-slate-800/80 cursor-pointer group-hover:border-slate-700 transition"
          >
            <img
              src={artifact.mediaUrl}
              alt={artifact.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            {hasSyntheticClues && (
              <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-rose-950/90 text-rose-300 border border-rose-800 text-[10px] font-mono">
                AI Clues Detected
              </span>
            )}
          </div>
        ) : (
          <div 
            onClick={() => setShowDetail(true)}
            className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-300 italic line-clamp-3 cursor-pointer hover:border-slate-700 transition"
          >
            "{artifact.content}"
          </div>
        )}

        {/* Meta Footer */}
        <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span className="truncate max-w-[120px]" title={artifact.source}>
            {artifact.source}
          </span>
          <span className="flex items-center space-x-1 text-slate-500">
            <Clock className="w-3 h-3" />
            <span>{artifact.timestamp.split(' ')[0]}</span>
          </span>
        </div>
      </div>

      {/* Forensic Deep Dive Modal */}
      {showDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 text-slate-200 shadow-2xl space-y-5">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-3">
                <span className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-indigo-400">
                  {getTypeIcon()}
                </span>
                <div>
                  <span className="text-[11px] font-mono text-indigo-400 uppercase">
                    Forensic Dossier #{artifact.id}
                  </span>
                  <h3 className="text-base font-bold text-white">{artifact.title}</h3>
                </div>
              </div>
              <button
                onClick={() => setShowDetail(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Media if present */}
            {artifact.mediaUrl && (
              <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950 max-h-72 flex items-center justify-center">
                <img
                  src={artifact.mediaUrl}
                  alt={artifact.title}
                  className="max-h-72 object-contain"
                />
              </div>
            )}

            {/* Content / OCR Text */}
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-1">
                Extracted Text / OCR / Transcript
              </span>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-200 font-mono leading-relaxed whitespace-pre-wrap">
                {artifact.content}
              </div>
            </div>

            {/* Metadata Grid */}
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-2">
                EXIF &amp; Provenance Headers
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">EXIF TIMESTAMP</span>
                  <span className="font-mono text-slate-200">
                    {artifact.metadata?.exifDate || 'Stripped / Not Available'}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">DEVICE / SENSOR</span>
                  <span className="font-mono text-slate-200">
                    {artifact.metadata?.cameraDevice || 'Unknown / Re-encoded'}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">GEOLOCATION TAGS</span>
                  <span className="font-mono text-slate-200">
                    {artifact.metadata?.geoCoordinates || 'Not Tagged'}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">SOFTWARE / GENERATOR</span>
                  <span className="font-mono text-slate-200">
                    {artifact.metadata?.softwareOrigin || 'Standard OS export'}
                  </span>
                </div>
              </div>
            </div>

            {/* Individual Analysis Notes */}
            {artifact.individualAnalysis && (
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-indigo-900/40 space-y-2">
                <span className="text-[10px] uppercase font-mono tracking-wider text-indigo-400 block">
                  Isolated Forensic Signals
                </span>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Visual Artifact Anomaly Score:</span>
                  <span className="font-mono font-bold text-amber-300">
                    {artifact.individualAnalysis.visualArtifactScore}/100
                  </span>
                </div>
                {artifact.individualAnalysis.syntheticClues.length > 0 && (
                  <ul className="text-xs text-rose-300 space-y-1 list-disc list-inside">
                    {artifact.individualAnalysis.syntheticClues.map((clue, idx) => (
                      <li key={idx}>{clue}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
