import React from 'react';
import { InvestigationCase } from '../types/forensic';
import { INVESTIGATION_CASES } from '../data/mockInvestigations';
import { FolderArchive, ArrowRight, ShieldAlert, Sparkles, Layers } from 'lucide-react';

interface CaseDossierSelectorProps {
  onSelectCase: (dossier: InvestigationCase) => void;
  activeCaseId?: string;
}

export const CaseDossierSelector: React.FC<CaseDossierSelectorProps> = ({ onSelectCase, activeCaseId }) => {
  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <div className="flex items-center space-x-2 text-indigo-400 text-xs font-mono uppercase tracking-wider">
          <FolderArchive className="w-4 h-4" />
          <span>Curated Multi-Artifact Investigation Dossiers</span>
        </div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Select an Investigation Scenario
        </h2>
        <p className="text-xs text-slate-400">
          Load complex real-world forensic cases combining multiple digital artifacts, social posts, satellite sensor telemetry, and EXIF chains.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {INVESTIGATION_CASES.map((dossier) => {
          const isSelected = activeCaseId === dossier.id;

          return (
            <div
              key={dossier.id}
              onClick={() => onSelectCase(dossier)}
              className={`group cursor-pointer rounded-2xl border p-5 flex flex-col justify-between space-y-4 transition-all duration-200 ${
                isSelected
                  ? 'bg-slate-900 border-indigo-500 shadow-xl shadow-indigo-500/10'
                  : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-3">
                {/* Thumbnail Header */}
                <div className="relative h-36 w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                  <img
                    src={dossier.thumbnail}
                    alt={dossier.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <span
                    className={`absolute bottom-2 left-2 text-[10px] font-mono px-2 py-0.5 rounded font-semibold border uppercase ${
                      dossier.threatLevel === 'Critical'
                        ? 'bg-rose-950/90 text-rose-300 border-rose-800'
                        : dossier.threatLevel === 'Elevated'
                        ? 'bg-amber-950/90 text-amber-300 border-amber-800'
                        : 'bg-emerald-950/90 text-emerald-300 border-emerald-800'
                    }`}
                  >
                    {dossier.threatLevel}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-mono uppercase text-indigo-400 block mb-1">
                    {dossier.category}
                  </span>
                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-200 transition">
                    {dossier.title}
                  </h3>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed line-clamp-3">
                  {dossier.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] font-mono text-slate-400 flex items-center space-x-1">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{dossier.artifacts.length} Digital Artifacts</span>
                </span>
                <span className="flex items-center space-x-1 text-indigo-400 group-hover:text-indigo-300 font-medium">
                  <span>{isSelected ? 'Active Case' : 'Load Case'}</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
